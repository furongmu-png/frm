# experiments/experience_buffer.py
"""Priority-sampled experience replay buffer.

Stores ``(obs, action, next_obs, error)`` transitions and supports
sampling by priority (error-weighted) or uniformly. Used by the
offline-consolidation loop in ``run_replay.py`` to let ZeroDataModel
re-hear past sensory transitions and consolidate learning.

Design notes:
- Backed by ``collections.deque(maxlen=capacity)`` so old experiences
  are evicted automatically once capacity is reached.
- Priority weights use ``error**alpha + epsilon`` (rank-free proportional
  sampling, à la Schaul et al. 2015). ``alpha=0`` recovers uniform
  sampling.
- ``beta`` is the importance-sampling correction exponent. At beta=0
  no correction is applied; at beta=1 the full IS weight is returned
  per sample. The consolidation loop uses these weights to scale
  prediction errors during re-learning (optional).
- The buffer is deterministic given the seed: the same seed + same
  insertion order produces the same sample sequence, across runs and
  platforms.
"""

from __future__ import annotations

import collections
import json
import random
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np


@dataclass
class Experience:
    """A single transition stored in the buffer."""

    obs: np.ndarray
    action: int
    next_obs: np.ndarray
    error: float            # proxy for prediction error / free energy
    step: int = 0           # global step when this was recorded
    metadata: dict = field(default_factory=dict)

    def to_json(self) -> dict:
        """JSON-friendly view (arrays → lists). Used for transcripts."""
        return {
            "obs": np.asarray(self.obs).tolist(),
            "action": int(self.action),
            "next_obs": np.asarray(self.next_obs).tolist(),
            "error": float(self.error),
            "step": int(self.step),
            "metadata": dict(self.metadata),
        }


@dataclass
class SampleBatch:
    """A batch of experiences returned by ``ExperienceBuffer.sample``."""

    experiences: list[Experience]
    weights: np.ndarray     # importance-sampling weights, shape (batch,)

    def __len__(self) -> int:
        return len(self.experiences)


class ExperienceBuffer:
    """A priority-sampled experience replay buffer.

    Parameters
    ----------
    capacity : int
        Maximum number of experiences. Older experiences are evicted
        once capacity is exceeded (FIFO via ``deque(maxlen=...)``).
    alpha : float
        Priority exponent. ``0`` → uniform; ``1`` → proportional to
        error; ``0.5`` → compromise. Default 0.6.
    beta : float
        Importance-sampling correction exponent. ``0`` → no
        correction; ``1`` → full IS correction. Default 0.4.
    epsilon : float
        Small constant added to priorities to avoid zero-probability
        samples when error=0. Default 1e-3.
    seed : int, optional
        RNG seed for reproducible sampling. ``None`` uses the global
        Python random state (non-deterministic across runs).
    """

    def __init__(
        self,
        capacity: int = 10000,
        alpha: float = 0.6,
        beta: float = 0.4,
        epsilon: float = 1e-3,
        seed: Optional[int] = 42,
    ):
        if capacity < 1:
            raise ValueError(f"capacity must be >= 1, got {capacity!r}")
        if alpha < 0:
            raise ValueError(f"alpha must be >= 0, got {alpha!r}")
        if not (0.0 <= beta <= 1.0):
            raise ValueError(f"beta must be in [0, 1], got {beta!r}")
        self.capacity = int(capacity)
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.epsilon = float(epsilon)
        self.seed = seed
        # ``deque(maxlen=...)`` evicts oldest entries automatically.
        self._buffer: collections.deque = collections.deque(maxlen=self.capacity)
        # Cached priorities — kept in lockstep with ``_buffer``.
        # Priority = error**alpha + epsilon. Recomputed on add().
        self._priorities: collections.deque = collections.deque(
            maxlen=self.capacity
        )
        # RNG: use Python's ``random.Random`` (affects only sampling,
        # not numpy's global state).
        self._rng = random.Random(seed)

    # ------------------------------------------------------------------ #
    # Properties
    # ------------------------------------------------------------------ #
    def __len__(self) -> int:
        return len(self._buffer)

    @property
    def is_empty(self) -> bool:
        return len(self._buffer) == 0

    # ------------------------------------------------------------------ #
    # Add a transition
    # ------------------------------------------------------------------ #
    def add(
        self,
        obs: np.ndarray,
        action: int,
        next_obs: np.ndarray,
        error: float,
        step: int = 0,
        metadata: Optional[dict] = None,
    ) -> None:
        """Store one transition in the buffer.

        Parameters
        ----------
        obs, next_obs : np.ndarray
            Observation vectors. Copied to avoid external mutation.
        action : int
            Discrete action taken.
        error : float
            Prediction error / free energy at this transition. Used
            to compute priority. Non-finite values are clamped to 0.
        step : int
            Global step counter when this was recorded. Useful for
            diagnostics.
        metadata : dict, optional
            Arbitrary per-experience metadata.
        """
        # Defensive copy so external code can mutate the arrays
        # without affecting stored experiences.
        obs_arr = np.array(obs, copy=True)
        next_arr = np.array(next_obs, copy=True)
        err = float(error) if np.isfinite(error) else 0.0
        # Clamp negative errors to 0 — priority is non-negative.
        if err < 0:
            err = 0.0
        exp = Experience(
            obs=obs_arr,
            action=int(action),
            next_obs=next_arr,
            error=err,
            step=int(step),
            metadata=dict(metadata or {}),
        )
        self._buffer.append(exp)
        self._priorities.append(err ** self.alpha + self.epsilon)

    # ------------------------------------------------------------------ #
    # Sampling
    # ------------------------------------------------------------------ #
    def sample(self, batch_size: int, mode: str = "priority") -> SampleBatch:
        """Sample a batch of experiences.

        Parameters
        ----------
        batch_size : int
            Number of experiences to return. Clamped to ``len(self)``.
        mode : str
            ``"priority"`` — sample proportional to ``error**alpha``
            (default). ``"uniform"`` — sample uniformly. ``"recent"`` —
            sample the most recent ``batch_size`` experiences.

        Returns
        -------
        SampleBatch
            ``experiences`` list + ``weights`` array of IS weights.
            For ``mode="uniform"`` and ``"recent"`` weights are all 1.0.
        """
        if self.is_empty:
            return SampleBatch(experiences=[], weights=np.array([]))
        n = len(self._buffer)
        k = max(1, min(int(batch_size), n))
        if mode == "recent":
            # Take the most recent k experiences directly.
            experiences = list(self._buffer)[-k:]
            weights = np.ones(k, dtype=np.float64)
            return SampleBatch(experiences=experiences, weights=weights)
        # Build sampling probabilities.
        if mode == "priority":
            priorities = np.array(self._priorities, dtype=np.float64)
            # Defensive: ensure non-negative and finite.
            priorities = np.where(
                np.isfinite(priorities) & (priorities > 0),
                priorities,
                self.epsilon,
            )
            probs = priorities / priorities.sum()
        elif mode == "uniform":
            probs = np.full(n, 1.0 / n, dtype=np.float64)
        else:
            raise ValueError(
                f"mode must be 'priority', 'uniform', or 'recent'; got "
                f"{mode!r}"
            )
        # Sample without replacement (standard for replay buffers —
        # makes the gradient estimates less correlated).
        idx = self._rng.sample(range(n), k=k)
        # ``random.sample`` is uniform; to apply our probabilities we
        # use numpy.random.choice-like logic via the cumulative
        # distribution. We do this manually to keep determinism with
        # ``self._rng`` (Python random).
        # Build the CDF and invert.
        cdf = np.cumsum(probs)
        u = np.array([self._rng.random() for _ in range(k)])
        chosen_idx = np.searchsorted(cdf, u, side="right")
        # Clamp (numerical safety).
        chosen_idx = np.clip(chosen_idx, 0, n - 1)
        # Deduplicate (if k > n this is impossible since k <= n; but
        # collisions in u → cdf mapping can occur). To avoid duplicates,
        # fall back to ``random.sample`` when priorities are uniform-ish.
        if len(set(chosen_idx.tolist())) < k:
            chosen_idx = np.array(self._rng.sample(range(n), k=k))
        experiences = [self._buffer[i] for i in chosen_idx]
        # Importance-sampling weights (for priority mode).
        if mode == "priority":
            # w_i = (N * p_i)**(-beta); normalise by max weight.
            sampled_probs = probs[chosen_idx]
            weights = (n * sampled_probs) ** (-self.beta)
            weights = weights / weights.max() if weights.max() > 0 else weights
        else:
            weights = np.ones(k, dtype=np.float64)
        return SampleBatch(experiences=experiences, weights=weights)

    # ------------------------------------------------------------------ #
    # Diagnostics
    # ------------------------------------------------------------------ #
    def stats(self) -> dict:
        """Return a JSON-serialisable stats dict."""
        if self.is_empty:
            return {
                "n": 0, "capacity": self.capacity,
                "alpha": self.alpha, "beta": self.beta,
            }
        errors = np.array([e.error for e in self._buffer])
        priorities = np.array(self._priorities)
        return {
            "n": len(self._buffer),
            "capacity": self.capacity,
            "alpha": self.alpha,
            "beta": self.beta,
            "error_mean": float(errors.mean()),
            "error_std": float(errors.std()),
            "error_min": float(errors.min()),
            "error_max": float(errors.max()),
            "priority_mean": float(priorities.mean()),
        }

    def save_json(self, path: str | Path) -> str:
        """Save buffer stats (not full contents) to a JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w") as f:
            json.dump(self.stats(), f, indent=2)
        return str(path)


# ------------------------------------------------------------------ #
# Self-test
# ------------------------------------------------------------------ #
def _self_test() -> None:
    """Smoke test the buffer."""
    buf = ExperienceBuffer(capacity=100, alpha=0.6, beta=0.4, seed=42)
    # Empty buffer.
    assert buf.is_empty
    assert len(buf) == 0
    batch = buf.sample(8)
    assert len(batch) == 0
    print("[OK] empty buffer sampling returns empty")
    # Add 20 experiences.
    rng = np.random.default_rng(0)
    for i in range(20):
        obs = rng.standard_normal(4)
        next_obs = rng.standard_normal(4)
        buf.add(obs, action=i % 4, next_obs=next_obs,
                error=float(i) / 20.0, step=i)
    assert len(buf) == 20
    assert not buf.is_empty
    print(f"[OK] added 20 experiences, len={len(buf)}")
    # Sample 8 with priority.
    batch = buf.sample(8, mode="priority")
    assert len(batch) == 8
    assert batch.experiences[0].obs.shape == (4,)
    print(f"[OK] priority sample: 8 exps, "
          f"errors={[f'{e.error:.2f}' for e in batch.experiences]}")
    # Verify high-error experiences are sampled more often.
    counts = np.zeros(20)
    for _ in range(2000):
        b = buf.sample(8, mode="priority")
        for e in b.experiences:
            # Identify by error value (unique per added exp).
            idx = int(round(e.error * 20))
            counts[idx] += 1
    high_err_count = counts[-5:].sum()
    low_err_count = counts[:5].sum()
    print(f"[OK] priority distribution: "
          f"high-err sampled {int(high_err_count)} times vs "
          f"low-err {int(low_err_count)} times")
    assert high_err_count > low_err_count, \
        "priority sampling did not favour high-error experiences"
    # Uniform sampling should be roughly balanced.
    counts = np.zeros(20)
    for _ in range(2000):
        b = buf.sample(8, mode="uniform")
        for e in b.experiences:
            idx = int(round(e.error * 20))
            counts[idx] += 1
    print(f"[OK] uniform distribution: "
          f"min bucket={int(counts.min())}, max bucket={int(counts.max())}")
    # Capacity eviction.
    for i in range(150):
        buf.add(np.zeros(4), action=0, next_obs=np.zeros(4),
                error=1.0, step=100 + i)
    assert len(buf) == 100, f"expected 100 after overflow, got {len(buf)}"
    print(f"[OK] capacity eviction: len={len(buf)} (capped at 100)")
    # Determinism.
    buf1 = ExperienceBuffer(capacity=50, seed=42)
    buf2 = ExperienceBuffer(capacity=50, seed=42)
    rng = np.random.default_rng(0)
    for i in range(30):
        obs = rng.standard_normal(4)
        buf1.add(obs, action=0, next_obs=obs, error=float(i), step=i)
        buf2.add(obs, action=0, next_obs=obs, error=float(i), step=i)
    b1 = buf1.sample(8, mode="priority")
    b2 = buf2.sample(8, mode="priority")
    same_idx = all(
        np.array_equal(b1.experiences[i].obs, b2.experiences[i].obs)
        for i in range(8)
    )
    assert same_idx, "seeded buffers produced different samples"
    print("[OK] determinism: same seed → same sample sequence")
    stats = buf.stats()
    print(f"[OK] stats: {stats}")
    print("\nALL TESTS PASSED")


if __name__ == "__main__":
    _self_test()
