// frontend/src/types.ts
// Type definitions for the "Window of Consciousness" protocol.

export interface Snapshot {
  step: number;
  timestamp: number;
  modality: string;
  frame_b64: string | null;
  text_block: string;
  action: number;
  free_energy: number;
  prediction_error: number;
  beta: number;
  belief_state: number[];
  causal_graph: CausalGraph;
  categories: Record<string, unknown>;
  kg_update: KGUpdate;
  self_authoring: string | null;
  event: string;
  // Phase-5 additions (optional for backwards compatibility with
  // snapshots produced by older backends).
  text_pos?: number;          // -1 when not reading text
  latent_3d?: [number, number, number];
}

export interface CausalGraph {
  nodes: { id: number; label: string }[];
  edges: { source: number; target: number; strength: number }[];
}

export interface KGUpdate {
  new_nodes: string[];
  new_edges: { source: string; target: string; weight: number }[];
}

export interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface GraphNode {
  id: string;
  label: string;
  size?: number;
  group?: string;
  modality?: string;
}

export interface GraphEdge {
  source: string;
  target: string;
  weight?: number;
  type?: string;
}

export interface Milestone {
  step: number;
  event: string;
  description: string;
}

/** A point in 3D latent space, derived from a Snapshot. */
export interface LatentPoint {
  step: number;
  modality: string;
  coords: [number, number, number];
  freeEnergy: number;
  predictionError: number;
}

export type CommandType = 'pause' | 'resume' | 'step' | 'set_speed' | 'intervention' | 'inject_question';

export interface WSCommand {
  type: CommandType;
  speed?: number;
  subtype?: string;
  params?: Record<string, unknown>;
  question?: string;
}
