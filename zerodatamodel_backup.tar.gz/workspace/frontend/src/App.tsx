// frontend/src/App.tsx
// Window of Consciousness — main layout (Phase 5).
//
// Three-column resizable layout (react-resizable-panels v4 API):
//   - Left   : Control panel (top) + Physical Sandbox (bottom)
//   - Center : Free Energy chart (top) + Text Heatmap (bottom)
//   - Right   : Latent Space 3D (top) + Self-Authoring placeholder (bottom)
//
// Header retains the connection status indicator. Each panel scrolls
// independently. BeliefStateRaw sits at the very bottom (collapsible).

import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import { Panel, Group, Separator } from 'react-resizable-panels';
import { useModelStore } from './store/useModelStore';
import SandboxView from './panels/SandboxView';
import FreeEnergyChart from './panels/FreeEnergyChart';
import LatentSpace3D from './panels/LatentSpace3D';
import TextExplorer from './panels/TextExplorer';
import TextHeatmap from './panels/TextHeatmap';
import ControlPanel from './panels/ControlPanel';
import SelfAuthoring from './panels/SelfAuthoring';
import BeliefStateRaw from './panels/BeliefStateRaw';
import CausalGraph from './panels/CausalGraph';
import KnowledgeGraphView from './panels/KnowledgeGraphView';
import StoryMode from './panels/StoryMode';

const panelWrapperStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  height: '100%',
  overflow: 'hidden',
};

const titleStyle: CSSProperties = {
  padding: '4px 10px',
  fontSize: '11px',
  color: '#888',
  borderBottom: '1px solid #1a1a1a',
  textTransform: 'uppercase',
  letterSpacing: '0.5px',
  flexShrink: 0,
};

const bodyStyle: CSSProperties = {
  flex: 1,
  overflow: 'auto',
  minHeight: 0,
};

const separatorStyle: CSSProperties = {
  background: '#222',
  position: 'relative',
};

function PanelWrap({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={panelWrapperStyle}>
      <div style={titleStyle}>{title}</div>
      <div style={bodyStyle}>{children}</div>
    </div>
  );
}

type LeftTab = 'sandbox' | 'text';
type RightTab = 'latent' | 'causal' | 'kg' | 'authoring' | 'story';

export default function App() {
  const { connect, disconnect, connected } = useModelStore();
  const [leftTab, setLeftTab] = useState<LeftTab>('sandbox');
  const [rightTab, setRightTab] = useState<RightTab>('latent');

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: '#0a0a0f', color: '#e0e0e0' }}>
      {/* Header — connection status indicator */}
      <header style={{ padding: '6px 16px', borderBottom: '1px solid #222', display: 'flex', alignItems: 'center', gap: '12px', background: '#111', flexShrink: 0 }}>
        <h1 style={{ fontSize: '15px', margin: 0, fontWeight: 600 }}>
          🧠 ZeroDataModel — Window of Consciousness
        </h1>
        <span style={{
          padding: '2px 8px', borderRadius: '4px', fontSize: '11px',
          background: connected ? '#1a3a1a' : '#3a1a1a',
          color: connected ? '#4ade80' : '#f87171',
        }}>
          {connected ? '● Connected' : '● Disconnected'}
        </span>
      </header>

      {/* Top: Control panel (full width) */}
      <div style={{ flexShrink: 0, borderBottom: '1px solid #222', background: '#0d0d12' }}>
        <ControlPanel />
      </div>

      {/* Main: three resizable columns */}
      <div style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <Group orientation="horizontal" style={{ height: '100%' }}>
          {/* Left column: control + sandbox/text */}
          <Panel defaultSize={25} minSize={15}>
            <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', borderBottom: '1px solid #1a1a1a', flexShrink: 0 }}>
                <button style={tabBtn(leftTab === 'sandbox')} onClick={() => setLeftTab('sandbox')}>Sandbox</button>
                <button style={tabBtn(leftTab === 'text')} onClick={() => setLeftTab('text')}>Text</button>
              </div>
              <div style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
                {leftTab === 'sandbox' ? <SandboxView /> : <TextExplorer />}
              </div>
            </div>
          </Panel>

          <Separator style={{ width: '4px', ...separatorStyle }} />

          {/* Center column: free energy chart + text heatmap */}
          <Panel defaultSize={40} minSize={20}>
            <Group orientation="vertical">
              <Panel defaultSize={50} minSize={15}>
                <PanelWrap title="Free Energy & Prediction Error">
                  <FreeEnergyChart />
                </PanelWrap>
              </Panel>
              <Separator style={{ height: '4px', ...separatorStyle }} />
              <Panel defaultSize={50} minSize={15}>
                <PanelWrap title="Text Stream Heatmap">
                  <TextHeatmap />
                </PanelWrap>
              </Panel>
            </Group>
          </Panel>

          <Separator style={{ width: '4px', ...separatorStyle }} />

          {/* Right column: tabbed panels (Latent 3D, Causal, KG, Authoring, Story) */}
          <Panel defaultSize={35} minSize={20}>
            <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', borderBottom: '1px solid #1a1a1a', flexShrink: 0, overflowX: 'auto' }}>
                <button style={tabBtn(rightTab === 'latent')} onClick={() => setRightTab('latent')}>Latent 3D</button>
                <button style={tabBtn(rightTab === 'causal')} onClick={() => setRightTab('causal')}>Causal</button>
                <button style={tabBtn(rightTab === 'kg')} onClick={() => setRightTab('kg')}>KG</button>
                <button style={tabBtn(rightTab === 'authoring')} onClick={() => setRightTab('authoring')}>Authoring</button>
                <button style={tabBtn(rightTab === 'story')} onClick={() => setRightTab('story')}>Story</button>
              </div>
              <div style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
                {rightTab === 'latent' && <LatentSpace3D />}
                {rightTab === 'causal' && <CausalGraph />}
                {rightTab === 'kg' && <KnowledgeGraphView />}
                {rightTab === 'authoring' && <SelfAuthoring />}
                {rightTab === 'story' && <StoryMode />}
              </div>
            </div>
          </Panel>
        </Group>
      </div>

      {/* Bottom: Belief State raw data (collapsible) */}
      <div style={{ flexShrink: 0 }}>
        <BeliefStateRaw />
      </div>
    </div>
  );
}

function tabBtn(active: boolean): CSSProperties {
  return {
    padding: '4px 12px',
    fontSize: '11px',
    background: active ? '#1a2a3a' : 'transparent',
    border: 'none',
    borderBottom: active ? '2px solid #3b82f6' : '2px solid transparent',
    color: active ? '#e0e0e0' : '#666',
    cursor: 'pointer',
  };
}
