# src/visualization/snapshot.py
"""Snapshot collector — lightweight model introspection after each think().

The ``SnapshotCollector`` reads the internal state of a ``ZeroDataModel``
instance and produces a JSON-serialisable dictionary conforming to the
"Window of Consciousness" protocol.  Collection is designed to be cheap
(< 1 ms for most fields) so it can be called after every cognitive cycle
without measurably impacting think() performance.

Protocol fields (see spec § V):
    step, timestamp, modality, frame_b64, text_block, action,
    free_energy, prediction_error, beta, belief_state,
    causal_graph, categories, kg_update, self_authoring, event,
    text_pos, latent_3d

Phase-5 additions:
    text_pos   : int   — character offset in the current text stream
                         (-1 when not reading text).
    latent_3d  : list  — first 3 components of belief_state, used by the
                         3D latent-space projection panel. [0,0,0] if no
                         belief is available.
"""

from __future__ import annotations

import base64
import io
import time
from dataclasses import dataclass, field
from typing import Any

import numpy as np


# ------------------------------------------------------------------ #
# Snapshot dataclass
# ------------------------------------------------------------------ #
@dataclass
class Snapshot:
    """A single cognitive-cycle snapshot, JSON-serialisable."""

    step: int = 0
    timestamp: float = 0.0
    modality: str = "unknown"
    frame_b64: str | None = None        # base64-encoded PNG
    text_block: str = ""
    action: int = 0
    free_energy: float = 0.0
    prediction_error: float = 0.0
    beta: float = 0.0
    belief_state: list[float] = field(default_factory=list)
    causal_graph: dict = field(default_factory=dict)
    categories: dict = field(default_factory=dict)
    kg_update: dict = field(default_factory=dict)
    self_authoring: str | None = None
    event: str = ""
    # Phase-5 additions.
    text_pos: int = -1                 # char offset in text stream, -1 if N/A.
    latent_3d: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])

    def to_dict(self) -> dict:
        """Return a JSON-serialisable dict."""
        return {
            "step": self.step,
            "timestamp": self.timestamp,
            "modality": self.modality,
            "frame_b64": self.frame_b64,
            "text_block": self.text_block,
            "action": self.action,
            "free_energy": round(self.free_energy, 6),
            "prediction_error": round(self.prediction_error, 6),
            "beta": round(self.beta, 6),
            "belief_state": [round(float(x), 6) for x in self.belief_state],
            "causal_graph": self.causal_graph,
            "categories": self.categories,
            "kg_update": self.kg_update,
            "self_authoring": self.self_authoring,
            "event": self.event,
            "text_pos": int(self.text_pos),
            "latent_3d": [round(float(x), 6) for x in self.latent_3d],
        }


# ------------------------------------------------------------------ #
# Snapshot collector
# ------------------------------------------------------------------ #
class SnapshotCollector:
    """Collects lightweight snapshots from a running ZeroDataModel.

    Usage (zero-intrusion pattern):

        collector = SnapshotCollector()
        # ... after each model.think(obs):
        snap = collector.collect(model, step=step, modality="physics", ...)
        streamer.broadcast(snap.to_dict())
    """

    def __init__(self, max_history: int = 5000):
        self._history: list[dict] = []
        self._max_history = max_history
        self._milestones: list[dict] = []
        # Track KG state for incremental updates.
        self._prev_kg_nodes: set[str] = set()
        self._prev_kg_edges: set[tuple] = set()
        # Free-energy tracking for event detection.
        self._fe_history: list[float] = []
        self._last_fe: float = 0.0

    # ------------------------------------------------------------------ #
    # Main collection method
    # ------------------------------------------------------------------ #
    def collect(
        self,
        model,
        step: int = 0,
        modality: str = "unknown",
        frame: np.ndarray | None = None,
        text_block: str = "",
        action: int = 0,
        free_energy: float | None = None,
        prediction_error: float | None = None,
        beta: float | None = None,
        kg_nodes: list[dict] | None = None,
        kg_edges: list[dict] | None = None,
        self_authoring: str | None = None,
        text_pos: int = -1,
    ) -> Snapshot:
        """Collect a snapshot from the model.

        Parameters
        ----------
        model : ZeroDataModel
            The model instance (read-only access to internal state).
        step : int
            Current cognitive-cycle step number.
        modality : str
            Active modality label: "physics", "text", "image", "audio", "code".
        frame : np.ndarray | None
            Optional raw frame (e.g. 128×128 uint8) to encode as base64 PNG.
        text_block : str
            The text currently being processed (if modality == "text").
        action : int
            Action taken this step.
        free_energy, prediction_error, beta : float | None
            Override values; if None, they are read from the model.
        kg_nodes, kg_edges : list[dict] | None
            Knowledge graph state for incremental diff.
        self_authoring : str | None
            Self-authored text (if generated this step).
        text_pos : int
            Character offset in the current text stream (call
            ``stream.tell()`` if a TextStream is being read). Pass -1
            when not reading text. Forwarded verbatim into the snapshot.
        """
        ts = time.time()

        # --- Belief state --- #
        try:
            gm = model.active_inference.generative_model
            belief = gm.belief_state
            belief_list = np.asarray(belief, dtype=float).flatten().tolist()
        except Exception:
            belief_list = []

        # --- Free energy (pragmatic) --- #
        if free_energy is None:
            try:
                free_energy = float(model.active_inference.free_energy_history[-1]) \
                    if len(model.active_inference.free_energy_history) > 0 else 0.0
            except Exception:
                free_energy = 0.0

        # --- Prediction error --- #
        if prediction_error is None:
            try:
                prediction_error = float(
                    np.linalg.norm(belief - model.active_inference.generative_model.predict_observation(belief))
                )
            except Exception:
                prediction_error = 0.0

        # --- Beta (exploration strength) --- #
        if beta is None:
            try:
                beta = float(model.active_inference._exploration_step)
            except Exception:
                beta = 0.0

        # --- Frame encoding --- #
        frame_b64 = None
        if frame is not None:
            frame_b64 = self._encode_frame_png(frame)

        # --- Causal graph (simplified) --- #
        causal_graph = self._extract_causal_graph(model)

        # --- Categories --- #
        categories = self._extract_categories(model)

        # --- KG incremental update --- #
        kg_update = self._compute_kg_diff(kg_nodes, kg_edges)

        # --- Event detection --- #
        event = self._detect_event(free_energy, modality, kg_update)

        # --- Latent 3D projection (first 3 belief components) --- #
        if belief_list and len(belief_list) >= 3:
            latent_3d = [float(belief_list[0]), float(belief_list[1]), float(belief_list[2])]
        else:
            latent_3d = [0.0, 0.0, 0.0]

        snap = Snapshot(
            step=step,
            timestamp=ts,
            modality=modality,
            frame_b64=frame_b64,
            text_block=text_block[:500] if text_block else "",
            action=action,
            free_energy=float(free_energy),
            prediction_error=float(prediction_error),
            beta=float(beta),
            belief_state=belief_list,
            causal_graph=causal_graph,
            categories=categories,
            kg_update=kg_update,
            self_authoring=self_authoring,
            event=event,
            text_pos=int(text_pos),
            latent_3d=latent_3d,
        )

        # Store in history.
        snap_dict = snap.to_dict()
        self._history.append(snap_dict)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

        # Track milestones.
        self._check_milestone(snap_dict)

        return snap

    # ------------------------------------------------------------------ #
    # Frame encoding
    # ------------------------------------------------------------------ #
    @staticmethod
    def _encode_frame_png(frame: np.ndarray) -> str:
        """Encode a numpy array as base64 PNG."""
        try:
            from PIL import Image
            arr = np.asarray(frame)
            if arr.ndim == 2:
                img = Image.fromarray(arr.astype(np.uint8), mode="L")
            elif arr.ndim == 3 and arr.shape[2] == 3:
                img = Image.fromarray(arr.astype(np.uint8), mode="RGB")
            elif arr.ndim == 3 and arr.shape[2] == 4:
                img = Image.fromarray(arr.astype(np.uint8), mode="RGBA")
            else:
                img = Image.fromarray(arr.astype(np.uint8))
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return base64.b64encode(buf.getvalue()).decode("ascii")
        except ImportError:
            # Fallback: raw bytes as base64 (no PNG compression).
            arr = np.asarray(frame, dtype=np.uint8).flatten()
            return base64.b64encode(arr.tobytes()).decode("ascii")

    # ------------------------------------------------------------------ #
    # Causal graph extraction
    # ------------------------------------------------------------------ #
    @staticmethod
    def _extract_causal_graph(model) -> dict:
        """Extract a simplified causal graph from the model's emergence engine."""
        try:
            emergence = model.emergence
            memory = emergence.memory
            patterns = memory._patterns
            labels = memory._labels
            nodes = []
            edges = []
            for i, (pat, label) in enumerate(zip(patterns, labels)):
                nodes.append({"id": i, "label": str(label) if label else f"node_{i}"})
                if i > 0:
                    # Simple chain: each node connected to previous.
                    strength = float(np.dot(pat, patterns[i - 1])) / (
                        np.linalg.norm(pat) * np.linalg.norm(patterns[i - 1]) + 1e-12
                    )
                    edges.append({
                        "source": i - 1, "target": i,
                        "strength": round(strength, 4),
                    })
            return {"nodes": nodes[:20], "edges": edges[:20]}
        except Exception:
            return {"nodes": [], "edges": []}

    # ------------------------------------------------------------------ #
    # Categories extraction
    # ------------------------------------------------------------------ #
    @staticmethod
    def _extract_categories(model) -> dict:
        """Extract category engine state."""
        try:
            cat = model.category_engine
            categories = {}
            for name, cat_obj in list(cat.categories.items())[:10]:
                categories[name] = {
                    "n_objects": len(cat_obj.objects),
                }
            return {
                "n_categories": len(cat.categories),
                "categories": categories,
                "n_functors": len(cat.functors),
            }
        except Exception:
            return {}

    # ------------------------------------------------------------------ #
    # KG incremental diff
    # ------------------------------------------------------------------ #
    def _compute_kg_diff(
        self,
        nodes: list[dict] | None,
        edges: list[dict] | None,
    ) -> dict:
        """Compute incremental KG changes since last snapshot."""
        if nodes is None and edges is None:
            return {"new_nodes": [], "new_edges": []}

        new_nodes = []
        new_edges = []
        if nodes is not None:
            current_node_ids = set()
            for n in nodes:
                nid = str(n.get("id", n.get("title", "")))
                current_node_ids.add(nid)
                if nid not in self._prev_kg_nodes:
                    new_nodes.append(nid)
            self._prev_kg_nodes = current_node_ids

        if edges is not None:
            current_edge_ids = set()
            for e in edges:
                src = str(e.get("source", ""))
                tgt = str(e.get("target", ""))
                eid = (src, tgt)
                current_edge_ids.add(eid)
                if eid not in self._prev_kg_edges:
                    new_edges.append({
                        "source": src, "target": tgt,
                        "weight": e.get("weight", 1.0),
                    })
            self._prev_kg_edges = current_edge_ids

        return {"new_nodes": new_nodes, "new_edges": new_edges}

    # ------------------------------------------------------------------ #
    # Event detection
    # ------------------------------------------------------------------ #
    def _detect_event(self, fe: float, modality: str, kg_update: dict) -> str:
        """Detect notable events for milestone tracking."""
        self._fe_history.append(fe)
        if len(self._fe_history) > 10:
            self._fe_history = self._fe_history[-10:]

        # High surprise: FE spike.
        if len(self._fe_history) >= 3:
            mean_recent = np.mean(self._fe_history[-3:])
            if fe > 2 * mean_recent and fe > 0.01:
                return "high_surprise"

        # New KG node discovered.
        if kg_update.get("new_nodes"):
            return "new_concept"

        # Collision (physics-specific, detected externally).
        if modality == "physics" and fe > self._last_fe * 3 and self._last_fe > 0:
            return "collision"

        self._last_fe = fe
        return ""

    # ------------------------------------------------------------------ #
    # Milestone tracking
    # ------------------------------------------------------------------ #
    def _check_milestone(self, snap: dict) -> None:
        """Record milestones for the story-mode timeline."""
        if snap["event"]:
            self._milestones.append({
                "step": snap["step"],
                "event": snap["event"],
                "description": f"Step {snap['step']}: {snap['event']} "
                               f"(FE={snap['free_energy']:.4f}, mod={snap['modality']})",
            })

        # FE reduction milestone (every 200 steps of progress).
        if snap["step"] > 0 and snap["step"] % 200 == 0:
            self._milestones.append({
                "step": snap["step"],
                "event": "checkpoint",
                "description": f"Reached step {snap['step']}, "
                               f"FE={snap['free_energy']:.4f}",
            })

    # ------------------------------------------------------------------ #
    # Public accessors
    # ------------------------------------------------------------------ #
    def get_history(self, start: int = 0, end: int | None = None) -> list[dict]:
        """Return historical snapshots in [start, end) range."""
        if end is None:
            end = len(self._history)
        return self._history[start:end]

    def get_milestones(self) -> list[dict]:
        """Return all recorded milestones."""
        return self._milestones

    def get_current_kg(self) -> dict:
        """Return the current KG state (nodes + edges from diff tracking)."""
        return {
            "nodes": list(self._prev_kg_nodes),
            "edges": [
                {"source": s, "target": t}
                for s, t in self._prev_kg_edges
            ],
        }

    @property
    def history_size(self) -> int:
        return len(self._history)
